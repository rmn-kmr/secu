/*************************************************************
 *
 * Author :      SecuGen Corporation
 * Description : FPMatcher interface.h source code module
 * Copyright(c): 2004 SecuGen Corporation, All rights reserved
 * History : 
 * date        person   comments
 * ======================================================
 *
 *
 *************************************************************/


GtkWidget* create_MatchDlg (void);


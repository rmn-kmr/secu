java -Djava.library.path=/usr/local/lib -cp ".:FDxSDKPro.jar" SecuGen.FDxSDKPro.samples.JSGFPLibTest

